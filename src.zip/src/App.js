import React, {Component} from 'react';
// import logo from './logo.svg';
import './App.css';
//import {Card} from './components/card/card.component';
import { CardList } from './components/card-list/card-list.component';
import {Label} from './components/label/label.component'
class App extends Component{

constructor(props){
  super(props)

  this.state = {
    monsters: [],
    searchField :''
  }


}
  
 componentDidMount(){
   fetch('https://jsonplaceholder.typicode.com/users')
   .then(response => response.json())
   .then(users => {
    console.log(users); 
    this.setState({monsters:users})})
 }


  render(){

    return(
      <div className="App">
        <div className="App-header">
          <input type="search" placeholder="Search Monster" onChange={e=> {
            this.setState({searchField: e.target.value},() =>{
              console.log(this.state);
            })
           }
            }/>
            <h1>{this.state.searchField}</h1>
          <CardList monsters={this.state.monsters}></CardList>
         </div>
      </div>
    )
  }
}

export default App;
